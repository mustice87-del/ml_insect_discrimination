"""
02_classification.py
====================
Train and evaluate five supervised classifiers on the 29-dimensional acoustic
feature matrix using stratified five-fold cross-validation.

Reproduces:
  - Table 1  : Feature statistics per treatment
  - Table 2  : Classifier accuracy & F1 (binary and 4-class)
  - Confusion matrices saved as PNG

Usage
-----
    python 02_classification.py --data data/acoustic_features.csv

The pre-extracted CSV is included in this package; the raw FLAC recordings
are not required to run this script.
"""

import argparse
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.model_selection import StratifiedKFold, cross_val_score, cross_val_predict
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix

warnings.filterwarnings('ignore')


# ── Classifiers ────────────────────────────────────────────────────────────────
CLASSIFIERS = {
    'Random Forest':     RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42),
    'SVM (RBF)':         SVC(kernel='rbf', C=10, gamma='scale', probability=True, random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=42),
    'KNN (k=5)':         KNeighborsClassifier(n_neighbors=5),
    'Logistic Reg.':     LogisticRegression(max_iter=1000, C=1.0, random_state=42),
}

TREATMENT_LABELS = {
    'insect': 'S. granarius',
    'worm':   'T. molitor',
    'powder': 'Substrate Control-1',
    'wheat':  'Substrate Control-2',
}


def load_data(csv_path: str):
    df = pd.read_csv(csv_path)
    y_raw = df['treatment'].values
    X = df.drop(columns=['treatment']).values
    feat_names = df.drop(columns=['treatment']).columns.tolist()
    return X, y_raw, feat_names


def print_table1(X, y, feat_names):
    """Feature statistics per treatment (Table 1)."""
    key_feats = ['rms', 'zcr', 'spec_centroid', 'spec_rolloff', 'band_1_5k', 'crest_factor']
    idx = [feat_names.index(f) for f in key_feats]
    labels = sorted(set(y))

    print('\n' + '=' * 70)
    print('TABLE 1 — Feature statistics (mean ± SD, n=60 windows each)')
    print('=' * 70)
    header = f"{'Feature':<22}" + ''.join(f'{TREATMENT_LABELS.get(l, l):>18}' for l in labels)
    print(header)
    print('-' * 70)
    units = {'rms': '(mV)', 'spec_centroid': '(kHz)', 'spec_rolloff': '(kHz)', 'band_1_5k': '(%)'}
    for i, feat in zip(idx, key_feats):
        col = feat.replace('spec_', '').replace('_', ' ').title()
        if feat in units:
            col += f' {units[feat]}'
        row = f'{col:<22}'
        for lbl in labels:
            vals = X[y == lbl, i]
            sc = 1 / 1000 if 'centroid' in feat or 'rolloff' in feat else 1
            sc = 1000 if feat == 'rms' else sc
            pct = 100 if feat == 'band_1_5k' else 1
            v = vals * sc * pct
            row += f'{v.mean():>10.3f}±{v.std():>6.3f}'
        print(row)
    print('=' * 70)


def print_table2(results_bin, results_4cls):
    """Classifier performance (Table 2)."""
    print('\n' + '=' * 78)
    print('TABLE 2 — 5-fold stratified cross-validation performance')
    print('=' * 78)
    print(f"{'Classifier':<22}  {'Binary Acc':>12}  {'Binary F1':>10}  "
          f"{'4-class Acc':>12}  {'4-class F1':>11}")
    print('-' * 78)
    for name in CLASSIFIERS:
        rb = results_bin[name];  r4 = results_4cls[name]
        print(f"{name:<22}  {rb['acc']:.3f}±{rb['std']:.3f}   "
              f"{rb['f1']:.3f}      "
              f"{r4['acc']:.3f}±{r4['std']:.3f}   "
              f"{r4['f1']:.3f}")
    print('=' * 78)


def save_confusion_matrix(cm, labels, title, path):
    cm_pct = cm.astype(float) / cm.sum(axis=1, keepdims=True) * 100
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    im = ax.imshow(cm_pct, cmap='Blues', vmin=0, vmax=100, aspect='auto')
    for i in range(len(labels)):
        for j in range(len(labels)):
            c = 'white' if cm_pct[i, j] > 60 else '#222'
            ax.text(j, i, f'{cm[i, j]}', ha='center', va='center',
                    color=c, fontsize=11, fontweight='bold')
    ax.set_xticks(range(len(labels))); ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, fontsize=8, rotation=20, ha='right')
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel('Predicted'); ax.set_ylabel('True')
    ax.set_title(title, fontsize=10, fontweight='bold', pad=8)
    plt.colorbar(im, ax=ax).set_label('Recall (%)', fontsize=8)
    plt.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f'  Saved: {path}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data/acoustic_features.csv')
    parser.add_argument('--out',  default='.')
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    X_raw, y_raw, feat_names = load_data(args.data)
    X = np.nan_to_num(X_raw, nan=0, posinf=1e6, neginf=-1e6)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    print_table1(X, y_raw, feat_names)

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # ── Binary: insect vs worm ─────────────────────────────────────────────────
    print('\nRunning binary classification (S. granarius vs T. molitor)...')
    mask_bin = (y_raw == 'insect') | (y_raw == 'worm')
    Xb = Xs[mask_bin]; yb_raw = y_raw[mask_bin]
    le_bin = LabelEncoder(); yb = le_bin.fit_transform(yb_raw)

    results_bin = {}
    for name, clf in CLASSIFIERS.items():
        acc = cross_val_score(clf, Xb, yb, cv=cv, scoring='accuracy')
        f1  = cross_val_score(clf, Xb, yb, cv=cv, scoring='f1_weighted')
        results_bin[name] = {'acc': acc.mean(), 'std': acc.std(), 'f1': f1.mean()}
        print(f'  {name:<22}: Acc={acc.mean():.3f}±{acc.std():.3f}  F1={f1.mean():.3f}')

    # Best binary CM (RF)
    rf = RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42)
    yb_pred = cross_val_predict(rf, Xb, yb, cv=cv)
    cm_bin  = confusion_matrix(yb, yb_pred)
    print('\n' + classification_report(yb, yb_pred, target_names=le_bin.classes_))
    save_confusion_matrix(
        cm_bin,
        [TREATMENT_LABELS.get(l, l) for l in le_bin.classes_],
        'Binary Confusion Matrix (RF)',
        out_dir / 'confusion_matrix_binary.png',
    )

    # ── 4-class ───────────────────────────────────────────────────────────────
    print('\nRunning 4-class classification (all treatments)...')
    le4 = LabelEncoder(); y4 = le4.fit_transform(y_raw)

    results_4cls = {}
    for name, clf in CLASSIFIERS.items():
        acc = cross_val_score(clf, Xs, y4, cv=cv, scoring='accuracy')
        f1  = cross_val_score(clf, Xs, y4, cv=cv, scoring='f1_weighted')
        results_4cls[name] = {'acc': acc.mean(), 'std': acc.std(), 'f1': f1.mean()}
        print(f'  {name:<22}: Acc={acc.mean():.3f}±{acc.std():.3f}  F1={f1.mean():.3f}')

    rf4 = RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42)
    y4_pred = cross_val_predict(rf4, Xs, y4, cv=cv)
    cm4     = confusion_matrix(y4, y4_pred)
    print('\n' + classification_report(y4, y4_pred, target_names=le4.classes_))
    save_confusion_matrix(
        cm4,
        [TREATMENT_LABELS.get(l, l) for l in le4.classes_],
        '4-class Confusion Matrix (RF)',
        out_dir / 'confusion_matrix_4class.png',
    )

    # ── Feature importance ─────────────────────────────────────────────────────
    rf_imp = RandomForestClassifier(n_estimators=300, random_state=42)
    rf_imp.fit(Xb, yb)
    imp = rf_imp.feature_importances_
    top10 = np.argsort(imp)[::-1][:10]
    print('\nTop-10 features (binary RF, mean decrease in impurity):')
    for rank, i in enumerate(top10, 1):
        print(f'  {rank:2d}. {feat_names[i]:<20}: {imp[i]:.4f}')

    print_table2(results_bin, results_4cls)


if __name__ == '__main__':
    main()
