"""
01_feature_extraction.py
========================
Extract a 29-dimensional acoustic feature vector from each 5-second window
of four one-hour FLAC recordings (192 kHz, 24-bit, mono, piezoelectric sensor).

Windows are sampled at one-per-minute intervals → 60 windows per treatment.

Usage
-----
    python 01_feature_extraction.py \\
        --insect path/to/insect.flac \\
        --worm   path/to/worm.flac   \\
        --powder path/to/powder.flac \\
        --wheat  path/to/wheat.flac  \\
        --out    data/

Outputs
-------
    data/X_features.npy       feature matrix  (240, 29)
    data/y_labels.npy         treatment labels (240,)
    data/feat_names.npy       feature names    (29,)
    data/acoustic_features.csv  combined CSV
"""

import argparse
import numpy as np
import soundfile as sf
from scipy import signal
from scipy.stats import skew, kurtosis
from pathlib import Path
import pandas as pd

# ── Constants ─────────────────────────────────────────────────────────────────
SR       = 192_000   # sampling rate (Hz)
WIN_SEC  = 5         # window length (s)
WIN_FR   = WIN_SEC * SR
STEP_SEC = 60        # one window per minute
NFFT     = 2048      # FFT size for MFCC filterbank
N_MELS   = 13        # number of mel bands / MFCCs
MEL_MAX  = 20_000    # upper mel frequency (Hz)


# ── Feature extraction ────────────────────────────────────────────────────────
def extract_features(data: np.ndarray, sr: int) -> dict:
    """Return a dict of 29 scalar features for a single audio window."""
    feats = {}

    # ── Time-domain (6) ───────────────────────────────────────────────────────
    feats['rms']          = float(np.sqrt(np.mean(data ** 2)))
    feats['peak']         = float(np.max(np.abs(data)))
    feats['crest_factor'] = float(feats['peak'] / (feats['rms'] + 1e-12))
    feats['zcr']          = float(np.mean(np.abs(np.diff(np.sign(data)))) / 2)
    feats['skewness']     = float(skew(data))
    feats['kurtosis']     = float(kurtosis(data))

    # ── Frequency-domain — PSD up to 50 kHz (10) ─────────────────────────────
    f, psd = signal.periodogram(data, sr, window='hann')
    mask   = f <= 50_000
    f50, p50 = f[mask], psd[mask]
    tot = float(np.sum(p50)) + 1e-30

    feats['spec_centroid'] = float(np.sum(f50 * p50) / tot)
    feats['spec_variance'] = float(np.sum(((f50 - feats['spec_centroid']) ** 2) * p50) / tot)
    sc, sv = feats['spec_centroid'], feats['spec_variance']
    feats['spec_skewness'] = float(
        np.sum(((f50 - sc) ** 3) * p50) / (tot * sv ** 1.5 + 1e-30)
    )
    cum = np.cumsum(p50) / tot
    feats['spec_rolloff']  = float(f50[np.searchsorted(cum, 0.85)])
    feats['spec_flatness'] = float(
        np.exp(np.mean(np.log(p50 + 1e-30))) / (np.mean(p50) + 1e-30)
    )
    for lo, hi in [(0, 1_000), (1_000, 5_000), (5_000, 15_000),
                   (15_000, 30_000), (30_000, 50_000)]:
        m = (f50 >= lo) & (f50 < hi)
        feats[f'band_{lo // 1000}_{hi // 1000}k'] = float(np.sum(p50[m]) / tot)

    # ── MFCC (13) — via mel filterbank on mean power spectrum ─────────────────
    freq_bins = np.fft.rfftfreq(NFFT, 1 / sr)
    hop       = NFFT // 2
    n_frames  = (len(data) - NFFT) // hop
    mean_psd  = np.zeros(NFFT // 2 + 1)
    for i in range(n_frames):
        frame = data[i * hop: i * hop + NFFT] * np.hanning(NFFT)
        mean_psd += np.abs(np.fft.rfft(frame)) ** 2
    mean_psd /= (n_frames + 1e-10)

    mel_top  = 2595 * np.log10(1 + MEL_MAX / 700)
    hz_pts   = 700 * (10 ** (np.linspace(0, mel_top, N_MELS + 2) / 2595) - 1)

    mel_e = []
    for i in range(1, N_MELS + 1):
        lo_h, cen, hi_h = hz_pts[i - 1], hz_pts[i], hz_pts[i + 1]
        filt = np.zeros(len(freq_bins))
        up = (freq_bins >= lo_h) & (freq_bins < cen)
        dn = (freq_bins >= cen) & (freq_bins < hi_h)
        if cen > lo_h:
            filt[up] = (freq_bins[up] - lo_h) / (cen - lo_h)
        if hi_h > cen:
            filt[dn] = (hi_h - freq_bins[dn]) / (hi_h - cen)
        mel_e.append(np.dot(mean_psd, filt))
    mel_e = np.array(mel_e)

    for n in range(N_MELS):
        feats[f'mfcc_{n + 1}'] = float(
            np.sum(
                np.log(mel_e + 1e-30)
                * np.cos(np.pi * n * (np.arange(N_MELS) + 0.5) / N_MELS)
            )
        )
    return feats


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='Extract acoustic features from FLAC recordings.')
    parser.add_argument('--insect', required=True, help='Path to S. granarius FLAC')
    parser.add_argument('--worm',   required=True, help='Path to T. molitor FLAC')
    parser.add_argument('--powder', required=True, help='Path to powder substrate control FLAC')
    parser.add_argument('--wheat',  required=True, help='Path to wheat substrate control FLAC')
    parser.add_argument('--out',    default='data', help='Output directory')
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    file_map = {
        'insect': args.insect,
        'worm':   args.worm,
        'powder': args.powder,
        'wheat':  args.wheat,
    }

    offsets_sec = list(range(0, 3600 - WIN_SEC, STEP_SEC))
    all_feats, all_labels = [], []
    feat_names = None

    for label, path in file_map.items():
        print(f'Processing {label} ...')
        for off in offsets_sec:
            frame = off * SR
            data, _ = sf.read(path, start=frame, stop=frame + WIN_FR, dtype='float32')
            if len(data) < WIN_FR:
                continue
            f = extract_features(data, SR)
            if feat_names is None:
                feat_names = list(f.keys())
            all_feats.append(list(f.values()))
            all_labels.append(label)
        print(f'  {all_labels.count(label)} windows extracted')

    X = np.nan_to_num(np.array(all_feats), nan=0.0, posinf=1e6, neginf=-1e6)
    y = np.array(all_labels)
    fn = np.array(feat_names)

    np.save(out_dir / 'X_features.npy', X)
    np.save(out_dir / 'y_labels.npy',   y)
    np.save(out_dir / 'feat_names.npy', fn)

    df = pd.DataFrame(X, columns=fn)
    df.insert(0, 'treatment', y)
    df.to_csv(out_dir / 'acoustic_features.csv', index=False)

    print(f'\nSaved: {X.shape[0]} windows × {X.shape[1]} features → {out_dir}')


if __name__ == '__main__':
    main()
