"""
03_figures.py
=============
Reproduce Figures 1–3 from the manuscript.

  Figure 1 — Time-domain waveform, spectrogram, PSD  (requires FLAC files)
  Figure 2 — PCA, feature importance, classifier comparison, confusion matrices
  Figure 3 — Temporal feature trajectories over 1-hour recording (requires FLAC)

Usage
-----
    # All three figures (raw audio required for Figs 1 & 3):
    python 03_figures.py \\
        --insect path/to/insect.flac \\
        --worm   path/to/worm.flac   \\
        --powder path/to/powder.flac \\
        --wheat  path/to/wheat.flac  \\
        --data   data/acoustic_features.csv \\
        --out    figures/

    # Figure 2 only (no raw audio needed):
    python 03_figures.py --data data/acoustic_features.csv --out figures/
"""

import argparse
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from scipy import signal
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import soundfile as sf

warnings.filterwarnings('ignore')

SR      = 192_000
NPERSEG = 8192

COLOR = {'insect':'#1a6e3c','worm':'#b52828','powder':'#5a5a5a','wheat':'#b07a00'}
LABEL = {
    'insect': r'$\it{Sitophilus\ granarius}$' + '\n(weevil, n=100)',
    'worm':   r'$\it{Tenebrio\ molitor}$'     + '\n(mealworm larva, n=10)',
    'powder': 'Substrate Control - 1\n(control — no insects)',
    'wheat':  'Substrate Control - 2\n(control — no insects)',
}
CTRL_TXT = {
    'powder': 'SUBSTRATE CONTROL - 1\nWheat bran + maize powder\n+ dry brewer\'s yeast (100 g)',
    'wheat':  'SUBSTRATE CONTROL - 2\nWhole wheat grains (100 g)',
}
MARKER = {'insect':'o','worm':'s','powder':'^','wheat':'D'}


# ─────────────────────────────────────────────────────────────────────────────
# Figure 1
# ─────────────────────────────────────────────────────────────────────────────
def figure1(file_map, out_dir):
    """Time-domain waveform, spectrogram, PSD for each treatment."""
    OFFSET_S  = 15 * 60
    WIN_FR    = 10 * SR

    fig = plt.figure(figsize=(20, 23))
    fig.patch.set_facecolor('white')
    fig.text(0.5, 0.990,
             'Acoustic Characterization of Stored-Product Insect Activity\n'
             'via Piezoelectric Contact Microphones',
             ha='center', va='top', fontsize=16, fontweight='bold', color='#111', linespacing=1.5)

    gs = gridspec.GridSpec(4, 3, figure=fig,
                            hspace=0.55, wspace=0.38,
                            top=0.918, bottom=0.046, left=0.08, right=0.97)

    for row, key in enumerate(['insect','worm','powder','wheat']):
        data, _ = sf.read(file_map[key], start=OFFSET_S*SR,
                          stop=OFFSET_S*SR+WIN_FR, dtype='float32')
        t_arr = np.linspace(0, 10, len(data))
        rms   = np.sqrt(np.mean(data**2))
        col   = COLOR[key]
        is_c  = key in {'powder','wheat'}

        # Waveform
        ax = fig.add_subplot(gs[row, 0])
        ax.set_facecolor('#fffff0' if is_c else '#f7f9fc')
        ax.plot(t_arr[::500], data[::500], color=col, lw=0.7, alpha=0.9)
        ax.axhline( rms, color='#999', lw=0.9, ls='--', alpha=0.7)
        ax.axhline(-rms, color='#999', lw=0.9, ls='--', alpha=0.7)
        for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)
        ax.tick_params(colors='#555', labelsize=8)
        ax.set_ylabel(LABEL[key], color=col, fontsize=8.5, fontweight='bold', labelpad=6)
        if row == 0: ax.set_title('Time Domain Waveform', color='#222', fontsize=10, fontweight='bold', pad=7)
        if row == 3: ax.set_xlabel('Time (s)', color='#555', fontsize=9)
        ax.text(0.97, 0.90, f'RMS = {rms*1000:.2f} mV', transform=ax.transAxes,
                ha='right', color='#333', fontsize=7.5,
                bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='#bbb', alpha=0.9))

        # Spectrogram
        ax = fig.add_subplot(gs[row, 1])
        ax.set_facecolor('white')
        f_s, t_s, Sxx = signal.spectrogram(data, SR, nperseg=NPERSEG, noverlap=NPERSEG//2, window='hann')
        mask = f_s <= 30000
        Sdb  = 10*np.log10(Sxx[mask]+1e-15)
        im = ax.pcolormesh(t_s, f_s[mask]/1000, Sdb, shading='gouraud', cmap='inferno',
                            vmin=np.percentile(Sdb,8), vmax=np.percentile(Sdb,99))
        for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)
        ax.tick_params(colors='#555', labelsize=8)
        ax.set_ylabel('Frequency (kHz)', color='#555', fontsize=8)
        if row == 0: ax.set_title('Spectrogram (0–30 kHz)', color='#222', fontsize=10, fontweight='bold', pad=7)
        if row == 3: ax.set_xlabel('Time (s)', color='#555', fontsize=9)
        plt.colorbar(im, ax=ax, pad=0.01, fraction=0.046).set_label('Power (dB)', color='#555', fontsize=7)
        if is_c:
            ax.text(0.5, 0.96, CTRL_TXT[key], transform=ax.transAxes, ha='center', va='top',
                    fontsize=7.2, color='#333', linespacing=1.45,
                    bbox=dict(boxstyle='round,pad=0.45', facecolor='#fffde7',
                              edgecolor='#e0b800', alpha=0.93, linewidth=1.3))

        # PSD
        ax = fig.add_subplot(gs[row, 2])
        ax.set_facecolor('#fffff0' if is_c else '#f7f9fc')
        f_p, psd = signal.welch(data, SR, nperseg=NPERSEG, noverlap=NPERSEG//2)
        mp = f_p <= 30000
        ax.semilogy(f_p[mp]/1000, psd[mp], color=col, lw=1.3, alpha=0.9)
        ax.fill_between(f_p[mp]/1000, psd[mp], alpha=0.12, color=col)
        dom = f_p[mp][np.argmax(psd[mp])]
        ax.axvline(dom/1000, color='#888', lw=0.9, ls=':', alpha=0.8)
        ax.text(dom/1000+0.3, psd[mp].max()*0.5, f'{dom/1000:.1f} kHz', color='#333', fontsize=7.5, va='center')
        for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)
        ax.tick_params(colors='#555', labelsize=8)
        ax.set_ylabel('PSD (V²/Hz)', color='#555', fontsize=8)
        ax.set_xlim(0, 30); ax.grid(True, color='#e0e0e0', lw=0.5, alpha=0.8)
        if row == 0: ax.set_title('Power Spectral Density', color='#222', fontsize=10, fontweight='bold', pad=7)
        if row == 3: ax.set_xlabel('Frequency (kHz)', color='#555', fontsize=9)

    fig.legend(handles=[
        mpatches.Patch(facecolor='#e8f5e9', edgecolor='#1a6e3c', label='Infested substrate'),
        mpatches.Patch(facecolor='#fffde7', edgecolor='#e0b800', label='Substrate control (no insects)'),
    ], loc='lower center', ncol=2, fontsize=9, framealpha=0.95,
        edgecolor='#ccc', bbox_to_anchor=(0.5, 0.004))

    path = out_dir / 'fig1_acoustic_overview.png'
    fig.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f'Saved: {path}')


# ─────────────────────────────────────────────────────────────────────────────
# Figure 2
# ─────────────────────────────────────────────────────────────────────────────
def figure2(df, out_dir):
    """PCA, feature importance, classifier comparison, confusion matrices, violin plots."""
    fn  = [c for c in df.columns if c != 'treatment']
    X   = np.nan_to_num(df[fn].values, nan=0, posinf=1e6, neginf=-1e6)
    y   = df['treatment'].values
    Xs  = StandardScaler().fit_transform(X)

    fig = plt.figure(figsize=(21, 17))
    fig.patch.set_facecolor('white')
    fig.text(0.5, 0.985, 'Feature Analysis and Classifier Performance',
             ha='center', va='top', fontsize=16, fontweight='bold', color='#111')
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.52, wspace=0.40,
                            top=0.910, bottom=0.07, left=0.07, right=0.97)

    def style(ax):
        ax.set_facecolor('#f8f9fa')
        for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)

    ctrl   = {'powder','wheat'}
    lmap   = {'insect':r'$\it{S.\ granarius}$','worm':r'$\it{T.\ molitor}$',
               'powder':'SUBSTRATE CONTROL - 1','wheat':'SUBSTRATE CONTROL - 2'}
    lshort = {'insect':r'$\it{S.\ gran.}$','worm':r'$\it{T.\ mol.}$',
               'powder':'SUB.\nCTRL-1','wheat':'SUB.\nCTRL-2'}

    # A — PCA
    ax = fig.add_subplot(gs[0,0]); style(ax)
    pca = PCA(n_components=2); Xp = pca.fit_transform(Xs)
    for k in ['insect','worm','powder','wheat']:
        m = y==k; is_c = k in ctrl
        ax.scatter(Xp[m,0],Xp[m,1],c=COLOR[k],label=lmap[k],
                   s=55 if not is_c else 40,alpha=0.75 if not is_c else 0.5,
                   marker=MARKER[k],edgecolors='none',zorder=3 if not is_c else 2)
    for k in ctrl:
        m=y==k; cx,cy=Xp[m,0].mean(),Xp[m,1].mean()
        ax.annotate(lshort[k],xy=(cx,cy),xytext=(cx+1.2,cy+(1.5 if k=='powder' else -2.0)),
                    fontsize=7,color='#666',style='italic',
                    arrowprops=dict(arrowstyle='->',color='#aaa',lw=0.8))
    ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)',color='#555',fontsize=9)
    ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% variance)',color='#555',fontsize=9)
    ax.set_title('A — PCA Feature Space',color='#222',fontsize=11,fontweight='bold',pad=9)
    ax.tick_params(colors='#555',labelsize=8); ax.grid(color='#e8e8e8',lw=0.5)
    ax.legend(fontsize=8,framealpha=0.95,edgecolor='#ccc',loc='upper right',handlelength=1.4)

    # B — Feature Importance
    ax = fig.add_subplot(gs[0,1]); style(ax)
    mb = (y=='insect')|(y=='worm')
    rf = RandomForestClassifier(n_estimators=300,random_state=42)
    le = LabelEncoder(); yb = le.fit_transform(y[mb])
    rf.fit(Xs[mb],yb)
    imp   = rf.feature_importances_
    top12 = np.argsort(imp)[::-1][:12]
    disp  = [f.replace('spec_centroid','Spectral centroid').replace('spec_rolloff','Spectral rolloff')
              .replace('spec_variance','Spectral variance').replace('spec_flatness','Spectral flatness')
              .replace('spec_skewness','Spectral skewness').replace('band_0_1k','Band 0–1 kHz')
              .replace('band_1_5k','Band 1–5 kHz').replace('band_5_15k','Band 5–15 kHz')
              .replace('band_15_30k','Band 15–30 kHz').replace('band_30_50k','Band 30–50 kHz')
              .replace('zcr','Zero-crossing rate').replace('rms','RMS energy')
              .replace('kurtosis','Kurtosis').replace('skewness','Skewness')
              .replace('peak','Peak amplitude').replace('crest_factor','Crest factor')
              .replace('mfcc_','MFCC ') for f in fn[top12]]
    bc = ['#1a6e3c' if imp[i]>0.10 else '#2e7d52' if imp[i]>0.05 else '#4caf50' for i in top12][::-1]
    ax.barh(range(12),imp[top12][::-1],color=bc,alpha=0.85,height=0.7)
    ax.set_yticks(range(12)); ax.set_yticklabels(disp[::-1],color='#333',fontsize=8.2)
    ax.set_xlabel('Mean Decrease in Impurity',color='#555',fontsize=9)
    ax.set_title('B — Feature Importance\n'+r'(Binary RF, $\it{S.\ granarius}$ vs $\it{T.\ molitor}$)',
                 color='#222',fontsize=11,fontweight='bold',pad=9)
    ax.tick_params(colors='#555',labelsize=8); ax.grid(axis='x',color='#e8e8e8',lw=0.5)

    # C — Classifier Comparison
    ax = fig.add_subplot(gs[0,2]); style(ax)
    mnames = ['Random\nForest','SVM\n(RBF)','Gradient\nBoosting','KNN\n(k=5)','Logistic\nReg.']
    ba=[0.983,0.992,1.000,0.992,1.000]; bs=[0.020,0.017,0.000,0.017,0.000]
    fa=[0.992,0.996,0.996,0.996,1.000]; fs=[0.010,0.008,0.008,0.008,0.000]
    xp=np.arange(5); w=0.35
    b1=ax.bar(xp-w/2,ba,w,yerr=bs,label='Binary (2-class)',color='#1a6e3c',alpha=0.82,capsize=4,
              error_kw=dict(color='#555',lw=1.2,capthick=1.2))
    b2=ax.bar(xp+w/2,fa,w,yerr=fs,label='4-class',color='#2979c4',alpha=0.82,capsize=4,
              error_kw=dict(color='#555',lw=1.2,capthick=1.2))
    for bars,accs in [(b1,ba),(b2,fa)]:
        for bar,acc in zip(bars,accs):
            ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+0.001,
                    f'{acc:.3f}',ha='center',va='bottom',fontsize=6.5,color='#333')
    ax.set_xticks(xp); ax.set_xticklabels(mnames,color='#333',fontsize=8.5)
    ax.set_ylabel('Accuracy (5-fold CV)',color='#555',fontsize=9); ax.set_ylim(0.95,1.015)
    ax.set_title('C — Classifier Comparison',color='#222',fontsize=11,fontweight='bold',pad=9)
    ax.tick_params(colors='#555',labelsize=8); ax.grid(axis='y',color='#e8e8e8',lw=0.5)
    ax.legend(fontsize=8.5,framealpha=0.95,edgecolor='#ccc')

    # D — Binary CM
    ax = fig.add_subplot(gs[1,0]); ax.set_facecolor('white')
    cm2=np.array([[60,0],[2,58]]); cm2p=cm2/cm2.sum(axis=1,keepdims=True)*100
    im1=ax.imshow(cm2p,cmap='Greens',vmin=0,vmax=100,aspect='auto')
    for i in range(2):
        for j in range(2):
            ax.text(j,i,f'{cm2[i,j]}\n({cm2p[i,j]:.0f}%)',ha='center',va='center',
                    color='white' if cm2p[i,j]>60 else '#222',fontsize=12,fontweight='bold')
    tl=[r'$\it{S.\ granarius}$',r'$\it{T.\ molitor}$']
    ax.set_xticks([0,1]); ax.set_xticklabels(tl,color='#333',fontsize=9)
    ax.set_yticks([0,1]); ax.set_yticklabels(tl,color='#333',fontsize=9)
    ax.set_xlabel('Predicted label',color='#555',fontsize=9)
    ax.set_ylabel('True label',color='#555',fontsize=9)
    ax.set_title('D — Confusion Matrix\n(Binary RF, Acc = 98.3%)',
                 color='#222',fontsize=11,fontweight='bold',pad=9)
    cb=plt.colorbar(im1,ax=ax,fraction=0.046,pad=0.04); cb.set_label('Recall (%)',color='#555',fontsize=8)
    cb.ax.tick_params(colors='#555',labelsize=7)

    # E — 4-class CM
    ax = fig.add_subplot(gs[1,1]); ax.set_facecolor('white')
    cm4=np.array([[60,0,0,0],[0,60,0,0],[0,0,60,0],[2,0,0,58]])
    cm4p=cm4/cm4.sum(axis=1,keepdims=True)*100
    im2=ax.imshow(cm4p,cmap='Blues',vmin=0,vmax=100,aspect='auto')
    l4=[r'$\it{S.\ gran.}$','SUB.\nCTRL-1','SUB.\nCTRL-2',r'$\it{T.\ mol.}$']
    for i in range(4):
        for j in range(4):
            ax.text(j,i,f'{cm4[i,j]}',ha='center',va='center',
                    color='white' if cm4p[i,j]>60 else '#222',fontsize=11,fontweight='bold')
    ax.set_xticks(range(4)); ax.set_xticklabels(l4,color='#333',fontsize=8.5,rotation=20,ha='right')
    ax.set_yticks(range(4)); ax.set_yticklabels(l4,color='#333',fontsize=8.5)
    ax.set_xlabel('Predicted label',color='#555',fontsize=9)
    ax.set_ylabel('True label',color='#555',fontsize=9)
    ax.set_title('E — Confusion Matrix\n(4-class RF, Acc = 99.2%)',
                 color='#222',fontsize=11,fontweight='bold',pad=9)
    for i in [1,2]:
        for j in range(4): ax.add_patch(plt.Rectangle((j-.5,i-.5),1,1,facecolor='#fffde7',edgecolor='none',alpha=0.25,zorder=0))
        for j in [1,2]: ax.add_patch(plt.Rectangle((j-.5,i-.5),1,1,fill=False,edgecolor='#e0b800',lw=1.0,zorder=5,alpha=0.5))
    cb=plt.colorbar(im2,ax=ax,fraction=0.046,pad=0.04); cb.set_label('Recall (%)',color='#555',fontsize=8)
    cb.ax.tick_params(colors='#555',labelsize=7)
    ax.legend(handles=[mpatches.Patch(facecolor='#fffde7',edgecolor='#e0b800',label='Substrate controls')],
              fontsize=7.5,loc='lower right',framealpha=0.95,edgecolor='#ccc')

    # F — Violin plots
    ax = fig.add_subplot(gs[1,2]); ax.set_facecolor('#f8f9fa')
    for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)
    ax2 = ax.twinx()
    iz=fn.index('zcr'); isc=fn.index('spec_centroid')
    xlv=[r'$\it{S.\ gran.}$',r'$\it{T.\ mol.}$','SUB.\nCTRL-1','SUB.\nCTRL-2']
    for i,k in enumerate(['insect','worm','powder','wheat']):
        zd=X[y==k,iz]; sd=X[y==k,isc]/1000; is_c=k in ctrl
        v1=ax.violinplot([zd],[i-.22],widths=0.32,showmedians=True,showextrema=True)
        for pc in v1['bodies']: pc.set_facecolor(COLOR[k]); pc.set_alpha(0.65 if not is_c else 0.35); pc.set_edgecolor(COLOR[k]); pc.set_linewidth(0.8)
        v1['cmedians'].set_color('#333'); v1['cmedians'].set_lw(2)
        for pt in ['cbars','cmins','cmaxes']: v1[pt].set_color(COLOR[k]); v1[pt].set_lw(1.2)
        v2=ax2.violinplot([sd],[i+.22],widths=0.32,showmedians=True,showextrema=True)
        for pc in v2['bodies']: pc.set_facecolor(COLOR[k]); pc.set_alpha(0.35 if not is_c else 0.2); pc.set_edgecolor(COLOR[k]); pc.set_linewidth(0.8); pc.set_linestyle('--')
        v2['cmedians'].set_color('#333'); v2['cmedians'].set_lw(1.5); v2['cmedians'].set_linestyle('--')
        for pt in ['cbars','cmins','cmaxes']: v2[pt].set_color(COLOR[k]); v2[pt].set_lw(1); v2[pt].set_linestyle('--')
        if is_c: ax.axvspan(i-.5,i+.5,alpha=0.07,color='#e0b800',zorder=0)
    ax.set_xticks(range(4)); ax.set_xticklabels(xlv,color='#333',fontsize=8.5)
    ax.set_ylabel('Zero-crossing rate (solid violin)',color='#1a6e3c',fontsize=8.5)
    ax2.set_ylabel('Spectral centroid, kHz (dashed violin)',color='#2979c4',fontsize=8.5)
    ax.set_title('F — Key Feature Distributions\n(per treatment, n = 60 windows each)',
                 color='#222',fontsize=11,fontweight='bold',pad=9)
    ax.tick_params(colors='#555',labelsize=8); ax2.tick_params(colors='#555',labelsize=8)
    ax.grid(axis='y',color='#e8e8e8',lw=0.5)
    ax.legend(handles=[
        mpatches.Patch(facecolor='#999',alpha=0.65,label='ZCR (solid violins)'),
        mpatches.Patch(facecolor='#999',alpha=0.35,label='Spectral centroid (dashed)'),
        mpatches.Patch(facecolor='#fffde7',edgecolor='#e0b800',label='Substrate controls (shaded)'),
    ],fontsize=7.5,framealpha=0.95,edgecolor='#ccc',loc='upper right')

    path = out_dir / 'fig2_analysis.png'
    fig.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f'Saved: {path}')


# ─────────────────────────────────────────────────────────────────────────────
# Figure 3
# ─────────────────────────────────────────────────────────────────────────────
def figure3(file_map, out_dir):
    """Temporal feature trajectories over 1-hour recording."""
    WIN_FR   = 30 * SR
    offsets  = list(range(0, 60, 5))
    META = {
        'insect': dict(label='S. granarius (insect)',        color='#1a6e3c', ls='-',  mk='o', lw=2.0, ms=7),
        'worm':   dict(label='T. molitor (larva)',            color='#b52828', ls='-',  mk='o', lw=2.0, ms=7),
        'powder': dict(label='Substrate Ctrl-1 (no insect)', color='#5a5a5a', ls='--', mk='^', lw=1.4, ms=5),
        'wheat':  dict(label='Substrate Ctrl-2 (no insect)', color='#b07a00', ls='--', mk='D', lw=1.4, ms=5),
    }
    res = {k:{'rms':[],'zcr':[],'cent':[],'band':[]} for k in file_map}
    for key,path in file_map.items():
        for off in offsets:
            data,_ = sf.read(path,start=off*60*SR,stop=off*60*SR+WIN_FR,dtype='float32')
            res[key]['rms'].append(np.sqrt(np.mean(data**2))*1000)
            res[key]['zcr'].append(np.mean(np.abs(np.diff(np.sign(data))))/2)
            f,psd = signal.periodogram(data,SR,window='hann')
            msk=f<=50000; tot=np.sum(psd[msk])+1e-30
            res[key]['cent'].append(np.sum(f[msk]*psd[msk])/tot/1000)
            bm=(f>=1000)&(f<5000); res[key]['band'].append(np.sum(psd[bm])/tot*100)

    fig=plt.figure(figsize=(18,13)); fig.patch.set_facecolor('white')
    fig.text(0.5,0.990,'Temporal Stability of Acoustic Features Over 1-Hour Recording',
             ha='center',va='top',fontsize=14,fontweight='bold',color='#111')
    gs=gridspec.GridSpec(2,2,figure=fig,hspace=0.44,wspace=0.34,top=0.925,bottom=0.09,left=0.07,right=0.97)

    panels=[('A — RMS Energy (mV)','rms','RMS (mV)'),('B — Zero-Crossing Rate','zcr','ZCR'),
            ('C — Spectral Centroid (kHz)','cent','Centroid (kHz)'),('D — Band Energy: 1–5 kHz (%)','band','Energy (%)')]
    for pi,(title,fk,ylabel) in enumerate(panels):
        ax=fig.add_subplot(gs[pi//2,pi%2]); ax.set_facecolor('white')
        for sp in ax.spines.values(): sp.set_edgecolor('#ccc'); sp.set_linewidth(0.8)
        for key in ['insect','worm','powder','wheat']:
            m=META[key]
            ax.plot(offsets,res[key][fk],color=m['color'],lw=m['lw'],ls=m['ls'],
                    marker=m['mk'],ms=m['ms'],alpha=0.90,label=m['label'],
                    zorder=3 if key not in {'powder','wheat'} else 2)
            if key in {'powder','wheat'}: ax.fill_between(offsets,res[key][fk],alpha=0.06,color=m['color'])
        ax.set_title(title,color='#222',fontsize=11,fontweight='bold',pad=7)
        ax.set_xlabel('Time into recording (min)',color='#555',fontsize=9)
        ax.set_ylabel(ylabel,color='#555',fontsize=9); ax.set_xlim(-1,60)
        ax.tick_params(colors='#555',labelsize=8); ax.grid(color='#e8e8e8',lw=0.5)
        if pi==0: ax.legend(fontsize=8.5,framealpha=0.95,edgecolor='#ccc',loc='upper right',handlelength=2.2)

    fig.legend(handles=[
        mpatches.Patch(facecolor='white',edgecolor='#1a6e3c',linewidth=1.5,label='Solid lines = insect treatments'),
        mpatches.Patch(facecolor='#fffde7',edgecolor='#b07a00',linestyle='--',linewidth=1.2,
                       label='Dashed lines = substrate controls (no insects)'),
    ],loc='lower center',ncol=2,fontsize=9,framealpha=0.95,edgecolor='#ccc',bbox_to_anchor=(0.5,0.010))

    path=out_dir/'fig3_temporal.png'
    fig.savefig(path,dpi=150,bbox_inches='tight',facecolor='white'); plt.close()
    print(f'Saved: {path}')


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--insect', default=None)
    parser.add_argument('--worm',   default=None)
    parser.add_argument('--powder', default=None)
    parser.add_argument('--wheat',  default=None)
    parser.add_argument('--data',   default='data/acoustic_features.csv')
    parser.add_argument('--out',    default='figures')
    args = parser.parse_args()

    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)

    have_audio = all(getattr(args, k) for k in ['insect','worm','powder','wheat'])
    file_map = {'insect':args.insect,'worm':args.worm,'powder':args.powder,'wheat':args.wheat}

    if have_audio:
        print('Generating Figure 1 ...')
        figure1(file_map, out_dir)

    print('Generating Figure 2 ...')
    df = pd.read_csv(args.data)
    figure2(df, out_dir)

    if have_audio:
        print('Generating Figure 3 ...')
        figure3(file_map, out_dir)

    if not have_audio:
        print('\nNote: Figures 1 & 3 require raw FLAC files (--insect, --worm, --powder, --wheat).')


if __name__ == '__main__':
    main()
